
Survey
    .StylesManager
    .applyTheme("modern");

function doOnCurrentPageChanged(survey) {
 if(survey.isFirstPage){
	 setupPageSelector(survey)
 }
}
function setupPageSelector(survey) {
	
	str = survey.pages.toString();
	
	
	var array = str.split(",");
	
	$.each(array,function(i){
	   console.log(array[i]);
	});
	
	text='';
    var selector = document.getElementById('pageSelector');
    for (var i = 0; i < survey.visiblePages.length; i++) {
        text += "<span class='navigationItem' onclick='survey.currentPageNo="+i+"'>"+array[i]+"</span>";
    }
	$("#pageSelector").html(text);}

var json = {
 "title": "PMO Maturity Assessment",
 "description": "The primary purpose of the PMO Assessment Toolbox is to identify strengths and weaknesses associated with program/project management practices within an organization.  The results of the assessment can be used to provide recommendations to improve overall project delivery. ",
 "pages": [
  {
   "name": "Introduction",
   "elements": [
    {
     "type": "html",
     "name": "Navigation",
     "html": "<div id='pageSelector'></div>"
    }
   ],
   "title": "Navigation"
  },
  {
   "name": "Alignment & Governance",
   "elements": [
    {
     "type": "matrix",
     "name": "q1",
     "title": "Is the Governance for the PMO Team defined and is it aligned with the key stakeholders?",
     "defaultValue": "-1",
     "columns": [
      {
       "value": "-1",
       "text": "not assessed"
      },
      {
       "value": "0",
       "text": "rudimentary"
      },
      {
       "value": "1",
       "text": "mimimum"
      },
      {
       "value": "2",
       "text": "basic"
      },
      {
       "value": "3",
       "text": "good"
      },
      {
       "value": "4",
       "text": "leading"
      }
     ]
    },
    {
     "type": "panel",
     "name": "panel2",
     "elements": [
      {
       "type": "comment",
       "name": "Q1S5",
       "title": "Are the key activities performed by the PMO documented?",
       "hideNumber": true,
       "rows": 1
      },
      {
       "type": "comment",
       "name": "Q1S1",
       "startWithNewLine": false,
       "title": "Are the PMO sponsors and stakeholders defined?",
       "hideNumber": true,
       "rows": 1,
       "textUpdateMode": "onBlur"
      },
      {
       "type": "comment",
       "name": "Q1S2",
       "title": "Is there a PMO operating model and reporting structure in place?",
       "hideNumber": true,
       "rows": 1
      },
      {
       "type": "comment",
       "name": "Q1S3",
       "startWithNewLine": false,
       "title": "Is the PMO driven by an overall vision and mission?",
       "hideNumber": true,
       "rows": 1
      },
      {
       "type": "comment",
       "name": "Q1S7",
       "title": "Is the Steering Committee or Change Advisory Board in place to make decisions (i.e. regarding scope, requirements)?",
       "hideNumber": true,
       "rows": 1
      },
      {
       "type": "comment",
       "name": "Q1S4",
       "startWithNewLine": false,
       "title": "Is there appropriate day-to-day interaction between PMO Staff and the Project/Program Managers.",
       "hideNumber": true,
       "rows": 1
      },
      {
       "type": "comment",
       "name": "Q1S6",
       "title": "Does the program have the necessary senior management support and leadership in the form of Program Sponsors and Program Steering Committee?",
       "hideNumber": true,
       "rows": 1
      }
     ],
     "indent": 2
    },
    {
     "type": "matrix",
     "name": "question2",
     "title": "Are projects following the standards and guidelines of the PMO?",
     "defaultValue": "-1",
     "columns": [
      {
       "value": "-1",
       "text": "not assessed"
      },
      {
       "value": "0",
       "text": "rudimentary"
      },
      {
       "value": "1",
       "text": "mimimum"
      },
      {
       "value": "2",
       "text": "basic"
      },
      {
       "value": "3",
       "text": "good"
      },
      {
       "value": "4",
       "text": "leading"
      }
     ]
    },
    {
     "type": "comment",
     "name": "question3",
     "title": "Does the PMO have the necessary resources and skills that are needed to support program management (i.e. knowledge of basic program and project management, financial skills, contracting skills, procurements skills, program management software, etc.). Is the PMO staff PMI certified?\n",
     "hideNumber": true,
     "rows": 1
    }
   ],
   "title": "Alignment & Governance"
  },
  {
   "name": "Methodology",
   "elements": [
    {
     "type": "matrix",
     "name": "question1",
     "title": "Has the PMO provided a Methodology?",
     "defaultValue": "-1",
     "columns": [
      {
       "value": "-1",
       "text": "not assessed"
      },
      {
       "value": "0",
       "text": "rudimentary"
      },
      {
       "value": "1",
       "text": "mimimum"
      },
      {
       "value": "2",
       "text": "basic"
      },
      {
       "value": "3",
       "text": "good"
      },
      {
       "value": "4",
       "text": "leading"
      }
     ]
    }
   ],
   "title": "Methodology"
  },
  {
   "name": "Program Charter",
   "title": "Program Charter"
  },
  {
   "name": "Policies & Procedures",
   "title": "Policies & Procedures"
  },
  {
   "name": "Scope Management",
   "title": "Scope Management"
  },
  {
   "name": "Requirements Management",
   "title": "Requirements Management"
  },
  {
   "name": "Release Management",
   "title": "Release Management"
  },
  {
   "name": "Work Plan Management",
   "title": "Work Plan Management"
  },
  {
   "name": "Performance & Reporting",
   "title": "Performance & Reporting"
  },
  {
   "name": "Communication Management",
   "title": "Communication Management"
  },
  {
   "name": "Issue Management",
   "title": "Issue Management"
  },
  {
   "name": "Risk Management",
   "title": "Risk Management"
  },
  {
   "name": "Quality Management",
   "title": "Quality Management"
  },
  {
   "name": "Procurement Management",
   "title": "Procurement Management"
  },
  {
   "name": "Resource Management",
   "title": "Resource Management"
  },
  {
   "name": "Records Management",
   "title": "Records Management"
  },
  {
   "name": "Business Case Management",
   "title": "Business Case Management"
  },
  {
   "name": "Financial Management",
   "title": "Financial Management"
  },
  {
   "name": "Stakeholder Management",
   "title": "Stakeholder Management"
  }
 ],
 "sendResultOnPageNext": true,
 "showPageNumbers": true
};




window.survey = new Survey.Model(json);

survey
    .onComplete
    .add(function (result) {
        document
            .querySelector('#surveyResult')
            .textContent = "Result JSON:\n" + JSON.stringify(result.data, null, 3);
    });

survey.showTitle = false;

$("#surveyElement").Survey({model: survey, onCurrentPageChanged: doOnCurrentPageChanged});

setupPageSelector(survey);
doOnCurrentPageChanged(survey);
survey.showTitle = false;